Title of the project: __Peer-graded Assignment: Bash, Make, Git, and GitHub__

Date make ran at:
Sat Apr  6 21:24:35 CEST 2019

Number of lines file guessinggame.sh contains:
      29
